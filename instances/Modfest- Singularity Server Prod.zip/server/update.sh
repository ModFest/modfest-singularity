#!/bin/bash
java -jar packwiz-installer-bootstrap.jar -s server "{SET ME TO YOUR PACK.TOML URL AAAA}"
