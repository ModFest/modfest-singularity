#!/bin/bash
java -jar packwiz-installer-bootstrap.jar -s server "https://modfest.github.io/modfest-singularity/pack.toml"
