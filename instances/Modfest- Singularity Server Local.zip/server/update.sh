#!/bin/bash
java -jar packwiz-installer-bootstrap.jar -s server "http://localhost:8080/pack.toml"
